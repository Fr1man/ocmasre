<?php
// Heading
$_['heading_title']    = 'Темы';

// Text
$_['text_success']     = 'Настройки успешно обновлены!';
$_['text_list']        = 'Список тем';

// Column
$_['column_name']      = 'Название';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'У Вас нет прав для редактирования расширения Темы!';

